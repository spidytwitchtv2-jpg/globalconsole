#!/usr/bin/env python3
"""
Verification script to check if passenger_wsgi.py is correct
Run this on the server to verify the setup
"""

import os
import sys

print("=" * 60)
print("Passenger WSGI Verification")
print("=" * 60)
print()

wsgi_file = os.path.join(os.path.dirname(__file__), 'passenger_wsgi.py')

if not os.path.exists(wsgi_file):
    print("❌ ERROR: passenger_wsgi.py not found!")
    sys.exit(1)

print(f"Checking: {wsgi_file}")
print()

# Read the file
with open(wsgi_file, 'r') as f:
    content = f.read()

# Check for mangum (should NOT be present)
if 'mangum' in content.lower() or 'Mangum' in content:
    print("❌ ERROR: passenger_wsgi.py contains 'mangum' references!")
    print("   Mangum is for AWS Lambda, not Passenger WSGI!")
    print("   You need to upload the updated file.")
    print()
    # Show where mangum appears
    lines = content.split('\n')
    for i, line in enumerate(lines, 1):
        if 'mangum' in line.lower() or 'Mangum' in line:
            print(f"   Line {i}: {line.strip()}")
    sys.exit(1)
else:
    print("✓ No mangum references found")

# Check for asgiref (should be present)
if 'asgiref' in content and 'WsgiToAsgi' in content:
    print("✓ asgiref.wsgi.WsgiToAsgi found (correct)")
else:
    print("❌ ERROR: asgiref.wsgi.WsgiToAsgi not found!")
    print("   The file needs to use asgiref for WSGI conversion.")
    sys.exit(1)

# Check for application variable
if 'application = WsgiToAsgi(app)' in content or 'application = WsgiToAsgi' in content:
    print("✓ WSGI application variable defined correctly")
else:
    print("⚠ WARNING: WSGI application variable might not be defined correctly")

print()
print("=" * 60)
print("File verification complete!")
print("=" * 60)
print()
print("If all checks passed, your passenger_wsgi.py is correct.")
print("If you're still getting mangum errors, try:")
print("1. Delete the old passenger_wsgi.py file completely")
print("2. Upload the new one")
print("3. Clear Python cache: find . -name '*.pyc' -delete")
print("4. Restart Passenger application in cPanel")

